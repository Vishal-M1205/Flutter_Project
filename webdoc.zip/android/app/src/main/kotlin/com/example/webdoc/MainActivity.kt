package com.example.webdoc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
