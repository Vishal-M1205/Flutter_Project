import 'package:flutter/material.dart';
import 'package:webdoc/firstpage.dart';
import 'package:webdoc/event.dart';
import 'package:webdoc/sos.dart';

void main() {
  runApp(TestPage());
}

class TestPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
            appBar: AppBar(
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Test'),
                  Icon(Icons.local_hospital), // Add your logo here
                ],
              ),
            ),
            body: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Doctor Created Health Cares',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Checkup' button press
                          },
                          style: ElevatedButton.styleFrom(
                              primary: Colors.blue,
                              onPrimary: Colors.white,
                              fixedSize: Size(100, 100),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text('Checkup'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Diabetes' button press
                          },
                          style: ElevatedButton.styleFrom(
                            primary: Colors.blue,
                            onPrimary: Colors.white,
                            fixedSize: Size(100, 100),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                          ),
                          child: Text('Diabetes'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Thyroid' button press
                          },
                          style: ElevatedButton.styleFrom(
                              primary: Colors.blue,
                              onPrimary: Colors.white,
                              fixedSize: Size(100, 100),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text('Thyroid'),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Checkup' button press
                          },
                          style: ElevatedButton.styleFrom(
                              primary: Colors.blue,
                              onPrimary: Colors.white,
                              fixedSize: Size(100, 100),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text('w-Health'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Diabetes' button press
                          },
                          style: ElevatedButton.styleFrom(
                            primary: Colors.blue,
                            onPrimary: Colors.white,
                            fixedSize: Size(100, 100),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                          ),
                          child: Text('Fever'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Thyroid' button press
                          },
                          style: ElevatedButton.styleFrom(
                              primary: Colors.blue,
                              onPrimary: Colors.white,
                              fixedSize: Size(100, 100),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text('Vitamin'),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Checkup' button press
                          },
                          style: ElevatedButton.styleFrom(
                              primary: Colors.blue,
                              onPrimary: Colors.white,
                              fixedSize: Size(100, 100),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text('Liver'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Diabetes' button press
                          },
                          style: ElevatedButton.styleFrom(
                            primary: Colors.blue,
                            onPrimary: Colors.white,
                            fixedSize: Size(100, 100),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                          ),
                          child: Text('Hairfall'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Thyroid' button press
                          },
                          style: ElevatedButton.styleFrom(
                              primary: Colors.blue,
                              onPrimary: Colors.white,
                              fixedSize: Size(100, 100),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text('Kidney'),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Women Care',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Checkup' button press
                          },
                          style: ElevatedButton.styleFrom(
                              primary: Colors.blue,
                              onPrimary: Colors.white,
                              fixedSize: Size(100, 100),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text('Pregnancy'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Diabetes' button press
                          },
                          style: ElevatedButton.styleFrom(
                            primary: Colors.blue,
                            onPrimary: Colors.white,
                            fixedSize: Size(100, 100),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                          ),
                          child: Text('Blood'),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Handle 'Thyroid' button press
                          },
                          style: ElevatedButton.styleFrom(
                              primary: Colors.blue,
                              onPrimary: Colors.white,
                              fixedSize: Size(100, 100),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: Text('PCOD'),
                        ),
                      ],
                    ),
                  ),

                  // Add more widgets here as needed
                ],
              ),
            ),
            bottomNavigationBar: DefaultTextStyle(
              style: TextStyle(
                overflow: TextOverflow.visible,
              ),
              child: BottomNavigationBar(
                type: BottomNavigationBarType.fixed,
                currentIndex: 0,
                onTap: (index) {
                  switch (index) {
                    case 0:
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => first()),
                      );
                      print('Home button pressed');
                      break;
                    case 1:
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => event()),
                      );
                      print('Doc button pressed');
                      break;
                    case 2:
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SOSPage()),
                      );
                      print('SOS button pressed');
                      break;
                    case 3:
                      print('Test button pressed');
                      break;
                    case 4:
                      print('Watch button pressed');
                      break;
                  }
                },
                items: [
                  BottomNavigationBarItem(
                    backgroundColor: Colors.grey,
                    icon: Icon(Icons.home),
                    label: 'Home',
                  ),
                  BottomNavigationBarItem(
                    backgroundColor: Colors.blue,
                    icon: Icon(
                      Icons.person,
                      color: Colors.blue,
                    ),
                    label: 'Doc',
                  ),
                  BottomNavigationBarItem(
                    backgroundColor: Colors.blue,
                    icon: Icon(
                      Icons.add_alert,
                      color: Colors.blue,
                    ),
                    label: 'SOS',
                  ),
                  BottomNavigationBarItem(
                    backgroundColor: Colors.blue,
                    icon: Icon(
                      Icons.medical_services,
                      color: Colors.blue,
                    ),
                    label: 'Test',
                  ),
                  BottomNavigationBarItem(
                    backgroundColor: Colors.blue,
                    icon: Icon(
                      Icons.watch,
                      color: Colors.blue,
                    ),
                    label: 'Watch',
                  ),
                ],
              ),
            )));
  }
}
