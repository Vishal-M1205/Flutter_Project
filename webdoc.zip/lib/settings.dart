import 'package:flutter/material.dart';
import 'package:webdoc/firstpage.dart';
import 'package:webdoc/test.dart';
import 'package:webdoc/event.dart';

void main() {
  runApp(SettingsPage());
}

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              // Handle back button press
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => first()),
              );
            },
          ),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Settings'),
            ],
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              FeatureCardWithImage(
                title: 'Hi Vishal',
                imageUrl: 'https://example.com/hi_vishal_image.png',
              ),
              FeatureCard(title: 'Doctor Consult History'),
              FeatureCard(title: 'Watch Records'),
              FeatureCard(title: 'Emergency SOS'),
              FeatureCard(title: 'Edit Address'),
              FeatureCard(title: 'Help'),
              FeatureCard(title: 'About Us'),
            ],
          ),
        ),
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final String title;

  FeatureCard({required this.title});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        title: Text(title),
      ),
    );
  }
}

class FeatureCardWithImage extends StatelessWidget {
  final String title;
  final String imageUrl;

  FeatureCardWithImage({required this.title, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8.0),
            child: Image.network(
              imageUrl,
              width: double.infinity,
              height: 150,
              fit: BoxFit.cover,
            ),
          ),
          ListTile(
            title: Text(title),
          ),
        ],
      ),
    );
  }
}
