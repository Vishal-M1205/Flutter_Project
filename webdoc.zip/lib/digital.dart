import 'package:flutter/material.dart';
import 'package:webdoc/event.dart';

void main() {
  runApp(DigitalConsultPage());
}

class DigitalConsultPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Digital Consult'),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => event()),
              );
            },
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              FeatureCard(title: 'Doctor 1'),
              FeatureCard(title: 'Doctor 2'),
              FeatureCard(title: 'Doctor 3'),
              FeatureCard(title: 'Doctor 4'),
              FeatureCard(title: 'Doctor 5'),
            ],
          ),
        ),
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final String title;

  FeatureCard({required this.title});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      elevation: 5,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Icon(Icons.account_circle, size: 50),
            SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
