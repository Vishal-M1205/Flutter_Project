import 'package:flutter/material.dart';
import 'package:webdoc/firstpage.dart';
import 'package:webdoc/sos.dart';
import 'package:webdoc/test.dart';

void main() {
  runApp(WatchPage());
}

class WatchPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Watch'),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 20),
              FeatureCardWithLogo(
                title: 'My Device',
                imageUrl:
                    'https://example.com/device_logo.png', // Replace with your URL
                imageSize: 150, // Adjust as needed
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Health',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        // Handle 'Checkup' button press
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Colors.blue,
                          onPrimary: Colors.white,
                          fixedSize: Size(100, 100),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                      child: Text('Workout'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        // Handle 'Thyroid' button press
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Colors.blue,
                          onPrimary: Colors.white,
                          fixedSize: Size(100, 100),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                      child: Text('Sleep'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        // Handle 'Thyroid' button press
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Colors.blue,
                          onPrimary: Colors.white,
                          fixedSize: Size(100, 100),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                      child: Text('Calorie'),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        // Handle 'Checkup' button press
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Colors.blue,
                          onPrimary: Colors.white,
                          fixedSize: Size(100, 100),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                      child: Text('Steps'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        // Handle 'Thyroid' button press
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Colors.blue,
                          onPrimary: Colors.white,
                          fixedSize: Size(100, 100),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                      child: Text('Heartrate'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        // Handle 'Thyroid' button press
                      },
                      style: ElevatedButton.styleFrom(
                          primary: Colors.blue,
                          onPrimary: Colors.white,
                          fixedSize: Size(100, 100),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                      child: Text('Temp'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: DefaultTextStyle(
          style: TextStyle(
            overflow: TextOverflow.visible,
          ),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            currentIndex: 4, // Assuming this is the Watch page
            onTap: (index) {
              // Handle bottom navigation button press
              switch (index) {
                case 0:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => first()),
                  );
                  // Home button pressed
                  break;
                case 1:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => first()),
                  );
                  // Doc button pressed
                  break;
                case 2:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SOSPage()),
                  );
                  // SOS button pressed
                  break;
                case 3:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => TestPage()),
                  );
                  // Test button pressed
                  break;
                case 4:
                  // Watch button pressed
                  break;
              }
            },
            items: [
              BottomNavigationBarItem(
                backgroundColor: Colors.grey,
                icon: Icon(Icons.home),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.person,
                  color: Colors.blue,
                ),
                label: 'Doc',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.add_alert,
                  color: Colors.blue,
                ),
                label: 'SOS',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.medical_services,
                  color: Colors.blue,
                ),
                label: 'Test',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.watch,
                  color: Colors.blue,
                ),
                label: 'Watch',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FeatureCardWithLogo extends StatelessWidget {
  final String title;
  final String imageUrl;
  final double imageSize;

  FeatureCardWithLogo({
    required this.title,
    required this.imageUrl,
    required this.imageSize,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      elevation: 5,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.network(
              imageUrl,
              height: imageSize,
              width: imageSize,
            ),
            SizedBox(height: 10),
            Text(
              title,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
