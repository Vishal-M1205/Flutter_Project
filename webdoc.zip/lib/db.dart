import 'package:mongo_dart/mongo_dart.dart';

void main() async {
  final db = Db('mongodb://152.58.212.80:27017/my_database');
  // or if using the API link
  // final db = Db('mongodb+srv://<username>:<password>@ap-south-1.aws.data.mongodb-api.com/app/data-nwbcd/endpoint/data/v1');

  try {
    await db.open();

    if (db.isConnected) {
      print('Connected to MongoDB server');

      // Example: Insert a document
      await db.collection('my_collection').insert({'key': 'value'});

      // Example: Query documents
      final documents = await db.collection('my_collection').find().toList();
      print('Documents: $documents');
    } else {
      print('Failed to connect to MongoDB server');
    }
  } finally {
    // Close the connection
    await db.close();
  }
}
