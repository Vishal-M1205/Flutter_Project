import 'package:flutter/material.dart';
import 'package:webdoc/firstpage.dart';
import 'package:webdoc/event.dart';
import 'package:webdoc/sos.dart';
import 'package:webdoc/test.dart';

void main() {
  runApp(AwarenessPage());
}

class AwarenessPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Awareness'),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              FeatureCard(
                title: 'Dengue',
                logo: Icons.local_hospital,
                onPressed: () {
                  // Handle 'Dengue' card press
                  print('Dengue card pressed');
                },
              ),
              FeatureCard(
                title: 'Malaria',
                logo: Icons.bug_report,
                onPressed: () {
                  // Handle 'Malaria' card press
                  print('Malaria card pressed');
                },
              ),
              FeatureCard(
                title: 'Chicken Pox',
                logo: Icons.ac_unit,
                onPressed: () {
                  // Handle 'Chicken Pox' card press
                  print('Chicken Pox card pressed');
                },
              ),
              FeatureCard(
                title: 'Pneumonia',
                logo: Icons.cloud,
                onPressed: () {
                  // Handle 'Pneumonia' card press
                  print('Pneumonia card pressed');
                },
              ),
              FeatureCard(
                title: 'Ringworm',
                logo: Icons.grain,
                onPressed: () {
                  // Handle 'Ringworm' card press
                  print('Ringworm card pressed');
                },
              ),
              FeatureCard(
                title: 'Typhoid',
                logo: Icons.sick,
                onPressed: () {
                  // Handle 'Typhoid' card press
                  print('Typhoid card pressed');
                },
              ),
              FeatureCard(
                title: 'Anaemia',
                logo: Icons.bloodtype,
                onPressed: () {
                  // Handle 'Anaemia' card press
                  print('Anaemia card pressed');
                },
              ),
              FeatureCard(
                title: 'Common Cold',
                logo: Icons.ac_unit,
                onPressed: () {
                  // Handle 'Common Cold' card press
                  print('Common Cold card pressed');
                },
              ),
              FeatureCard(
                title: 'Hepatitis',
                logo: Icons.bug_report,
                onPressed: () {
                  // Handle 'Hepatitis' card press
                  print('Hepatitis card pressed');
                },
              ),
            ],
          ),
        ),
        bottomNavigationBar: DefaultTextStyle(
          style: TextStyle(
            overflow: TextOverflow.visible,
          ),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            currentIndex: 0,
            onTap: (index) {
              // Handle bottom navigation button press
              switch (index) {
                case 0:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => first()),
                  );
                  // Home button pressed
                  break;
                case 1:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => event()),
                  );
                  // Doc button pressed
                  break;
                case 2:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => SOSPage()),
                  );
                  // SOS button pressed
                  break;
                case 3:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => TestPage()),
                  );
                  // Test button pressed
                  break;
                case 4:
                  // Watch button pressed
                  break;
              }
            },
            items: [
              BottomNavigationBarItem(
                backgroundColor: Colors.grey,
                icon: Icon(Icons.home),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.person,
                  color: Colors.blue,
                ),
                label: 'Doc',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.add_alert,
                  color: Colors.blue,
                ),
                label: 'SOS',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.medical_services,
                  color: Colors.blue,
                ),
                label: 'Test',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.watch,
                  color: Colors.blue,
                ),
                label: 'Watch',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final String title;
  final IconData logo;
  final VoidCallback? onPressed;

  FeatureCard({
    required this.title,
    required this.logo,
    this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        onTap: onPressed,
        leading: Icon(
          logo,
          size: 40,
          color: Colors.blue,
        ),
        title: Text(
          title,
          overflow: TextOverflow.visible,
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
