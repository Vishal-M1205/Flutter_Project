import 'package:flutter/material.dart';
import 'package:webdoc/firstpage.dart';
import 'package:webdoc/test.dart';
import 'package:webdoc/event.dart';

void main() {
  runApp(SOSPage());
}

class SOSPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('SOS Functions'),
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 100),
              ElevatedButton(
                onPressed: () {
                  // Handle 'SOS' button press
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.red,
                  onPrimary: Colors.white,
                  shape: CircleBorder(),
                  padding: EdgeInsets.all(
                      150), // Increased padding for a larger button
                ),
                child: Image.network(
                  'https://i.postimg.cc/XY6GWNrm/istockphoto-1129235631-612x612.jpg', // Replace with your URL
                  height: 100,
                  width: 100,
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  // Handle 'SOS Contact List' button press
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.blue,
                  onPrimary: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: EdgeInsets.all(30),
                ),
                child: Text('SOS Contact List'),
              ),
            ],
          ),
        ),
        bottomNavigationBar: DefaultTextStyle(
          style: TextStyle(
            overflow: TextOverflow.visible,
          ),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            currentIndex: 2, // Assuming this is the SOS page
            onTap: (index) {
              // Handle bottom navigation button press
              switch (index) {
                case 0:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => first()),
                  );
                  // Home button pressed
                  break;
                case 1:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => event()),
                  );
                  // Doc button pressed
                  break;
                case 2:
                  // SOS button pressed
                  break;
                case 3:
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => TestPage()),
                  );
                  // Test button pressed
                  break;
                case 4:
                  // Watch button pressed
                  break;
              }
            },
            items: [
              BottomNavigationBarItem(
                backgroundColor: Colors.grey,
                icon: Icon(Icons.home),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.person,
                  color: Colors.blue,
                ),
                label: 'Doc',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.add_alert,
                  color: Colors.blue,
                ),
                label: 'SOS',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.medical_services,
                  color: Colors.blue,
                ),
                label: 'Test',
              ),
              BottomNavigationBarItem(
                backgroundColor: Colors.blue,
                icon: Icon(
                  Icons.watch,
                  color: Colors.blue,
                ),
                label: 'Watch',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
