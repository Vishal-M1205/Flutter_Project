import 'package:flutter/material.dart';
import 'package:webdoc/aware.dart';
import 'package:webdoc/event.dart';
import 'package:webdoc/settings.dart';
import 'package:webdoc/sym.dart';
import 'package:webdoc/test.dart';
import 'package:webdoc/sos.dart';
import 'package:webdoc/watch.dart';

void main() {
  runApp(first());
}

class first extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              backgroundImage: NetworkImage(
                  'https://i.postimg.cc/VLW1Sz73/Whats-App-Image-2024-02-17-at-7-12-49-AM.jpg'),
            ),
            SizedBox(width: 10),
            Container(
              width: 150, // Adjust the width as needed
              child: Text(
                'Hi Vishal',
                overflow: TextOverflow.visible,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SettingsPage()),
              );
              // Handle settings button press
            },
          ),
          IconButton(
            icon: Icon(Icons.notifications),
            onPressed: () {
              // Handle notifications button press
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AwarenessPage()),
                );
                // Handle 'Awareness' button press
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.blue,
                onPrimary: Colors.white,
                fixedSize: Size(400, 40),
              ),
              child: Row(
                children: [
                  Icon(Icons.info),
                  SizedBox(width: 10),
                  Text('Awareness', style: TextStyle(fontSize: 18)),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => event()),
                );
                // Handle 'Health Checks and Consult' button press
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.blue,
                onPrimary: Colors.white,
                fixedSize: Size(400, 40),
              ),
              child: Row(
                children: [
                  Icon(Icons.local_hospital),
                  SizedBox(width: 8),
                  Text(
                    'Health Checks and Consult',
                    style: TextStyle(fontSize: 18),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SymptomPage()),
                );
                // Handle 'Enter Symptoms' button press
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.blue,
                onPrimary: Colors.white,
                fixedSize: Size(400, 40),
              ),
              child: Row(
                children: [
                  Icon(Icons.input),
                  SizedBox(width: 8),
                  Text(
                    'Enter Symptoms',
                    style: TextStyle(fontSize: 18),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => event()),
                );
                // Handle 'Book Consult' button press
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.blue,
                onPrimary: Colors.white,
                fixedSize: Size(400, 40),
              ),
              child: Row(
                children: [
                  Icon(Icons.book),
                  SizedBox(width: 8),
                  Text(
                    'Book Consult',
                    style: TextStyle(fontSize: 18),
                  ),
                ],
              ),
            ),
          ),
          Text(
            'Book Doctor Consult',
            textAlign: TextAlign.right,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
            overflow: TextOverflow.visible,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                width: 130,
                height: 125, // Adjust the width as needed
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => event()),
                    );
                    // Handle 'Hospital Visit' button press
                    print('Hospital Visit button pressed');
                  },
                  icon: Icon(Icons.local_hospital),
                  label: Text(
                    'Hospital Visit',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
              Container(
                width: 130,
                height: 125, // Adjust the width as needed
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => event()),
                    );
                    // Handle 'Video Consult' button press
                    print('Video Consult button pressed');
                  },
                  icon: Icon(Icons.video_call),
                  label: Text(
                    'Video Consult',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      bottomNavigationBar: DefaultTextStyle(
        style: TextStyle(
          overflow: TextOverflow.visible,
        ),
        child: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          currentIndex: _currentIndex,
          onTap: (index) {
            // Handle bottom navigation item press
            setState(() {
              _currentIndex = index;
            });
            switch (index) {
              case 0:
                print('Home button pressed');
                break;
              case 1:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => event()),
                );
                // Doc button pressed
                print('Doc button pressed');
                break;
              case 2:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SOSPage()),
                );
                // SOS button pressed
                print('SOS button pressed');
                break;
              case 3:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => TestPage()),
                );
                // Test button pressed
                print('Test button pressed');
                break;
              case 4:
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => WatchPage()),
                );
                // Watch button pressed
                print('Watch button pressed');
                break;
            }
          },
          items: [
            BottomNavigationBarItem(
              backgroundColor: Colors.grey,
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              backgroundColor: Colors.blue,
              icon: Icon(
                Icons.person,
                color: Colors.blue,
              ),
              label: 'Doc',
            ),
            BottomNavigationBarItem(
              backgroundColor: Colors.blue,
              icon: Icon(
                Icons.add_alert,
                color: Colors.blue,
              ),
              label: 'SOS',
            ),
            BottomNavigationBarItem(
              backgroundColor: Colors.blue,
              icon: Icon(
                Icons.medical_services,
                color: Colors.blue,
              ),
              label: 'Test',
            ),
            BottomNavigationBarItem(
              backgroundColor: Colors.blue,
              icon: Icon(
                Icons.watch,
                color: Colors.blue,
              ),
              label: 'Watch',
            ),
          ],
        ),
      ),
    );
  }
}
